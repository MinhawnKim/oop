#include "student.h"

student::student() {

}

student::student(char* name) {

}

student::student(int student_id) {

}

student::student(char *name, int student_id) {

}

int student::get_student_id() {

}

int student::get_id() {

}
