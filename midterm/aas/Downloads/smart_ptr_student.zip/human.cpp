//
// Created by 김혁진 on 2019/10/28.
//

#include "human.h"

human::human() {

}

human::human(char name[]) {

}

char *human::get_name() {

}

int human::get_id() {

}
