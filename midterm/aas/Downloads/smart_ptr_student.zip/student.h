#ifndef SMART_PTR_STUDENT_H
#define SMART_PTR_STUDENT_H

#include "human.h"



#endif //SMART_PTR_STUDENT_H
